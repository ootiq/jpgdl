# jpgdl

Just a simple script and library image downloader and saving it in JPEG format.
