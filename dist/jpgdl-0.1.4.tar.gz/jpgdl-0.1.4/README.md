# jpgdl

Just a simple script and library image downloader and saving it in JPEG format, nothing fancy.

### Use Library

```python3
from jpgdl import JPGDL

JPGDL.download(download_url='https://picsum.photos/200/300', filename='test')
```

### CLI

```
jpgdl -h
```

#### Made By:

##### TheBoringDude
